(() => {
  // Public tick data only; no account token is needed or stored.
  const APP_ID = "1089";
  const $ = (id) => document.getElementById(id);
  const symbolEl = $("symbol"), tickCountEl = $("tickCount");
  let socket = null, ticks = [], requestId = 1;

  function setStatus(message, kind = "") {
    $("statusText").textContent = message;
    $("statusDot").className = "status-dot" + (kind ? " " + kind : "");
  }
  function getLastDigit(quote) {
    const text = String(quote);
    const digits = text.match(/\d/g);
    return digits && digits.length ? Number(digits[digits.length - 1]) : null;
  }
  function render() {
    const count = Number(tickCountEl.value);
    const sample = ticks.slice(-count);
    $("collected").textContent = ticks.length;
    $("sampleLabel").textContent = sample.length + " / " + count + " sample ticks";
    $("historyLabel").textContent = sample.length + " shown";

    if (!ticks.length) {
      $("quote").textContent = "—"; $("lastDigit").textContent = "—";
      $("digitGrid").innerHTML = ""; $("topDigit").textContent = "—";
      $("topPercent").textContent = "—";
      return;
    }
    const latest = ticks[ticks.length - 1];
    $("quote").textContent = latest.quote;
    $("lastDigit").textContent = latest.digit;
    const counts = Array(10).fill(0);
    sample.forEach(t => { if (t.digit !== null) counts[t.digit]++; });
    const max = Math.max(1, ...counts);
    const ranked = counts.map((n, digit) => ({digit, n, pct: sample.length ? n / sample.length * 100 : 0}))
      .sort((a,b) => b.n - a.n || a.digit - b.digit);
    const top = ranked[0];
    $("topDigit").textContent = sample.length ? top.digit : "—";
    $("topPercent").textContent = sample.length ? top.pct.toFixed(1) + "%" : "—";
    $("digitGrid").innerHTML = ranked.map(item =>
      `<div class="digit-card ${item.digit === top.digit && sample.length ? "top" : ""}" tabindex="0" title="Digit ${item.digit}: ${item.n} occurrences">
        <span class="digit">${item.digit}</span><span class="digit-count">${item.n} · ${item.pct.toFixed(1)}%</span>
        <div class="bar"><span style="width:${item.n / max * 100}%"></span></div></div>`
    ).join("");
    $("history").innerHTML = sample.slice().reverse().map(t =>
      `<span class="tick-chip">${escapeHtml(t.quote)} <b>${t.digit === null ? "—" : t.digit}</b></span>`
    ).join("") || '<p class="muted">Waiting for ticks…</p>';
  }
  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
  function stop() {
    if (socket) { socket.onclose = null; socket.close(); socket = null; }
    setStatus("Stopped");
    $("connectBtn").disabled = false; $("stopBtn").disabled = true;
  }
  function connect() {
    stop();
    ticks = []; render();
    setStatus("Connecting…");
    $("connectBtn").disabled = true; $("stopBtn").disabled = false;
    try {
      socket = new WebSocket("wss://ws.derivws.com/websockets/v3?app_id=" + APP_ID);
      socket.onopen = () => {
        setStatus("Connected", "live");
        socket.send(JSON.stringify({ticks: symbolEl.value, subscribe: 1, req_id: requestId++}));
      };
      socket.onmessage = event => {
        let data;
        try { data = JSON.parse(event.data); } catch (_) { return; }
        if (data.error) { setStatus(data.error.message || "API error", "error"); return; }
        if (data.tick) {
          const quote = String(data.tick.quote);
          ticks.push({quote, digit: getLastDigit(quote)});
          const keep = Math.max(1000, Number(tickCountEl.value));
          if (ticks.length > keep) ticks = ticks.slice(-keep);
          render();
        }
      };
      socket.onerror = () => setStatus("Connection error", "error");
      socket.onclose = () => {
        socket = null;
        setStatus("Connection closed", "error");
        $("connectBtn").disabled = false; $("stopBtn").disabled = true;
      };
    } catch (error) {
      setStatus("Could not connect", "error");
      $("connectBtn").disabled = false; $("stopBtn").disabled = true;
    }
  }
  $("connectBtn").addEventListener("click", connect);
  $("stopBtn").addEventListener("click", stop);
  symbolEl.addEventListener("change", () => { if (socket) connect(); });
  tickCountEl.addEventListener("change", render);
  render();
})();